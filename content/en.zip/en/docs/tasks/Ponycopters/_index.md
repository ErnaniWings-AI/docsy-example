---
title: Working with Ponycopters
description: >
  A short lead description about this section page. Text here can also be **bold** or _italic_ and can even be split over multiple paragraphs.
date: 2017-01-05
---

{{% pageinfo %}}
This is a placeholder page. Replace it with your own content.
{{% /pageinfo %}}

This is the section landing page.
